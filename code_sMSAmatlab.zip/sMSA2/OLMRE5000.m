%OLMRE5000, over lord Membrane Real Estate
%August 2025
%June/July 2024
%top management code: cycles through experimental data series, calls FBA function with
%constraints, and logs output
%Ross P. Carlson

% experimental data indexing
%rows: 1-23, aerobic cstr/batch, glucose limited, consensus data MG1655
%rows: 24-46, aerobic cstr/batch, glucose limited, consensus data NCM3722
%rows: 47-67, aerobic batch G, GA, L, A  MG1655
%rows: 68-74, aerobic cstr nitrogen limited MG1655
%rows: 75-78, aerobic cstr iron limited MG1655
%rows: 79-94, anaerobic, glucose limited consensus data MG1655

i = 1 ; %experimental condition counter, above***
imax = 23 ; %max i for experimental conditions***
zmax = 20 ; %fMSA range considered (start at 1% go to 20%)
rowtrack = 97 ; % number of model reactions plus added functions (EcMREpaper1/2)

outmF = zeros(rowtrack, 1);  
outsF = zeros(rowtrack, 1);


while i < imax+1
    
[mF,sF]=functionEc5000(i, zmax, rowtrack); %used for both cost and no cost

outmF = [outmF mF]; %mean of 100 reaction fluxes
outsF = [outsF sF]; %standard deviation of 100 reaction fluxes

i = i+ 1;

end

outmF(:,1) = [];
outsF(:,1) = [];

%summary output name
Descr = ["260322Ec5002MGSummary.xlsx"]; 

file = Descr; 
        %mean flux from 100 simulations               
        tab = 'outmF'; 
        
        xlswrite(file,outmF,tab);
        %standard deviation from 100 simulations        
        tab = 'outsF'; 
        
        xlswrite(file,outsF,tab);