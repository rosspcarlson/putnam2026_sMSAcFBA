
% September 2025
% Function to run FBA using experimental measurements as constraints

function [FBAflux] = sMSAFBAfunction5000(model_name,objective, qglc, mu, MREc, MREmu)
 
% Open model
model = readCbModel(model_name);
 
% Set model objective
model = changeObjective(model,objective);
 
% Set substrate         ***
model = changeRxnBounds(model,'G1',qglc,'b'); % glucose
model = changeRxnBounds(model,'T2in',0,'b'); % acetate
model = changeRxnBounds(model,'T4in',0,'b'); % lactate
model = changeRxnBounds(model,'IM3b',0,'b'); % lactate,(prevents IM3/IM3b LDH loop in place of ndh)
model = changeRxnBounds(model,'T11in',0,'b'); %  pyruvate
model = changeRxnBounds(model,'T12in',0,'b'); % succinate

model = changeRxnBounds(model,'T2cost',0,'b'); % MSA cost acetate
model = changeRxnBounds(model,'T4cost',0,'b'); % MSA cost lactate
model = changeRxnBounds(model,'T5cost',0,'b'); % formate secretion rate, MSA cost
model = changeRxnBounds(model,'T11cost',0,'b'); % pyruvate secretion, MSA cost
model = changeRxnBounds(model,'T12cost',0,'b'); % Succinate secretion rate, MSA cost

model = changeRxnBounds(model,'T25',MREc,'u'); % growth independent MRE constant
model = changeRxnBounds(model,'BIOM',mu,'b'); % specific growth rate (h^-1)
% model = changeRxnBounds(model,'ATPm',qatp,'b'); % specific maintenance energy flux

%model = changeRxnBounds(model,'IM1',0,'b'); % O2 sensitive Pfl (very little effect on mu or Yx/S)
%model = changeRxnBounds(model,'T1',0,'b'); % O2 sensitive ethanol dehydrogenase (very little effect on mu or Yx/S)
model = changeRxnBounds(model,'R4',0,'b'); % AppBC enzyme functionally similar to Cyd, 0.93H+/e, high affinity for O2
model = changeRxnBounds(model,'T7r',0,'b'); % O2 transport, aerobic/anaerobic

%membrane surface area costs Q10 = 2.0
%growth rate dependent PtsG saturation, MG1655 (mu max = 0.69/h, Ks = 5 uM, or anaerobic mu max = 0.5/h)

%aerobic
%if mu < 0.69
    %satnGlc = 1.4925*mu ;

%anaerobic
if mu < 0.51
    satnGlc = 2*mu ;

else
    satnGlc = 1 ;
end

%nitrogen saturated conditions
satnNH3 = 1 ;

%ptsGCorr = 1 ;
%ATPCorr = 1;
%ETCCorr = 1;
 
%corrected PWF 251004 set 16
ptsGCorr =  (-8.579*mu^2 + 15.745*mu +0.7434 ) ;
ATPCorr = (2.9103*mu^2 - 3.2*mu + 1.994) ;
ETCCorr = (0.3749*mu^2 + 0.7179*mu + 1.0344) ;

% membrane surface area costs, parameters corrected for T, Q10 = 2
model.S(55,1) = (-0.097*ptsGCorr)/(satnGlc) ; %G1 PtsG ***adjusted for satn and experimental data
model.S(55,2) = -3.041 ; %G2a ABC glucose

model.S(55,30) = -0.028 ; %TCA7 Frd
model.S(55,39) = -0.028 ; %IM3b Ldh
model.S(55,42) = -0.116 ; %IM6 Pox
model.S(55,43) = -0.185 ; %IM7 Fdh
model.S(55,29) = -0.028*(ETCCorr) ; %TCA6 Sdh ***adjusted for experimental data
model.S(55,45) = -0.378*(ETCCorr) ; %R1 Nuo ***adjusted for experimental data
model.S(55,46) = -0.01*(ETCCorr) ; %R2 Ndh ***adjusted for experimental data
model.S(55,47) = -0.077*(ETCCorr) ; %R3 Cyd ***adjusted for experimental data
model.S(55,49) = -0.049*(ETCCorr) ; %R5 Cyo ***adjusted for experimental data
model.S(55,53) = -0.057*(ETCCorr) ; %R8 Pnt ***adjusted for experimental data
model.S(55,50) = -0.087*(ATPCorr); %R6f ATP synthase, forward direction
model.S(55,51) = -0.087*(ATPCorr); %R6r ATP synthase, reverse direction

model.S(55,64) = -MREmu ; %growth rate dependendent MRE parameter in biomass reaction 
model.S(55,66) = 0 ; %T2 acetate out
model.S(55,67) = -0.186 ; %T2cost acetate
model.S(55,68) = -0.186 ; %T2in acetate

model.S(55,69) = -0.172/satnNH3 ; %T3 NH4+, adjusted for transporter saturation

model.S(55,70) = 0 ; %T4 lactate out
model.S(55,71) = -0.186 ; %T4cost lactate
model.S(55,72) = -0.186 ; %T4in lactate

model.S(55,73) = 0 ; %T5 formate out
model.S(55,74) = -0.186 ; %T5cost formate
 
model.S(55,75) = -0 ; %T6 CO2
model.S(55,76) = -0 ; %T6in CO2

model.S(55,78) = -0.151 ; %T8 SO4
model.S(55,79) = -0 ; %T9 H2O
model.S(55,80) = -0 ; %T9in H2O
model.S(55,81) = -0.151 ; %T10 PO4

model.S(55,82) = 0 ; %T11 pyruvate, no cost  
model.S(55,83) = -0.186 ; %T11cost pyruvate  
model.S(55,84) = -0.186 ; %T11in pyruvate  

model.S(55,85) = 0 ; %T12 succinate, no cost  
model.S(55,86) = -0.186 ; %T12cost succinate  
model.S(55,87) = -0.186 ; %T12in succinate  

% Solve model for optimization criterion
%FBAsolution = optimizeCbModel(model,'min'); %min G1 glucose
FBAsolution = optimizeCbModel(model,'max'); %max ATPm  
FBAflux = FBAsolution.x;

end