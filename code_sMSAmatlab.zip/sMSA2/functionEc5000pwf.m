function[mF, sF] = functionEc5000pwf(zmax, rowtrack) 

%Ec5000AeroCost/NoCost
%December 2022-December 2023, March 2024, June/July 2024, August 2025  
%Ross P. Carlson
%cost analysis for aerobic cultures, glucose and iron limited (nitrogen
%separate due to saturation of transporter)
%analyzes median experimental chemostat data using surface area constraints
%using temperature corrected TO numbers
%corrects the transporter saturation term for the chemostat conditions

%SA:V Si et al 2017 MG1655 (fMSA 1-20%)
MREc = [1.4089;	2.8179;	4.2268;	5.6358; 7.0447;	8.4537;	9.8627;	11.2716;	12.6806;	14.08953;	15.4985;	16.9075;	18.3164;	19.7254;	21.1343;	22.5433;	23.9522;	25.3612;	26.7702;	28.1791]; %non growth parameters for (1-20%) MRE 
MREmu = [0.2883;	0.5766;	0.865;	1.1533; 1.4416;	1.73;	2.0183;	2.3066;	2.595;	2.8833;	3.1716;	3.46;	3.7483;	4.0366;	4.325;	4.6133;	4.9016;	5.19;	5.4783;	5.7666] ; %growth associated parameters for (1-20%) MRE

%SA:V Si et al 2017 NCM3722 (fMSA 1-20%)
%MREc = [1.9370;	3.8741;	5.8112;	7.7483; 9.6854;	11.6225;	13.5595;	15.4966;	17.4337;	19.3708;	21.3079;	23.245;	25.1820;	27.1191;	29.0562;	30.9933;	32.9304;	34.8675;	36.8045;	38.7416]; %non growth parameters for (1-20%) MRE 
%MREmu = [0.5508;	1.1016;	1.6525;	2.2033; 2.7541;	3.305;	3.8558;	4.4066;	4.9575;	5.5083;	6.0591;	6.61;	7.1608;	7.7116;	8.2625;	8.8133;	9.3641;	9.915;	10.4658;	11.0166] ; %growth associated parameters for (1-20%) MRE

% limiting substrate transporter saturation for growth rates in data set,
% PtsG glucose transporter saturation, Amt NH4+ transporter saturation
satnGlc = [0.15	0.22	0.30	0.37	0.45	0.50	0.55	0.60	0.65	0.70	0.75	0.80	0.84	0.90	0.94	0.99	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	0.10	0.20	0.30	0.40	0.50	0.60	0.70	0.80	0.90	1.00	1.00	1.00	1.00	1.00	1.00	1.00];
satnNH3 = [1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	0.15	0.15	0.30	0.30	0.45	0.60	0.82	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00]; 

%experimental data (order of columns: growth
%rate, glucose, pyruvate, succinate, lactate out, lactate in, formate,
%acetate out, acetate in, ethanol out)

%rows: 1-23, aerobic cstr/batch, glucose limited, consensus data MG1655
%rows: 24-46, aerobic cstr/batch, glucose limited, consensus data NCM3722
%rows: 47-67, aerobic batch G, GA, L, A  MG1655
%rows: 68-74, aerobic cstr nitrogen limited MG1655
%rows: 75-78, aerobic cstr iron limited MG1655
%rows: 79-92, anaerobic, glucose limited consensus data MG1655


RM = [0.80	10.76	0.00	0.00	0.00	0.00	0.00	4.35	0.00	0.00];

%error in experimental data, same order as original rates  
RMEr = [0.02	0.75	0.00	0.00	0.00	0.00	0.00	0.30	0.00	0.00];
 

pwf = [
7.9	0.9	1.1
7.95	0.95	1.05
7.8	1	1
7.85	0.9	1.1
8	0.9	1.1
8	0.95	1.05
8.05	1	1
8.05	1	1
7.9	0.9	1.1
7.95	0.9	1.1
7.8	0.95	1.05
7.85	1	1
8	0.95	1.05
8.05	1	1
8.05	1	1
7.9	0.9	1.1
7.95	0.9	1.1
7.8	0.95	1.05
7.85	1	1
7.7	1	1
];

totno = 100 ; %100 perturbations
rxnno = 91; %reactions in model (EcMREpaper1)

%vector to be pulled from function

mF = zeros(rowtrack, zmax); %median flux for each reaction or function
sF = zeros(rowtrack, zmax); %standard deviation for each reaction or function

%number of experimental conditions
LR = size(RM,1);
%number of experimental rates considered
LC = size(RM,2);


z = 1; %pwf index

while z < zmax+1  %cycles through MSA %, set with z and zmax

%output
MREout = zeros(rxnno + 6,totno);
 
loop = 1; 

%temporary RM with perturbations
RMtemp = zeros(LR, LC);

%one hundred perturbations loop
while loop <totno + 1  

%module for perturbing the experimental values within their limits

x = 1; % row counter
y = 1;  % column counter

  
    while y < LC+1 
        
        RMtemp(1,y) = RM(x,y) + (randi([-1,1],1,1))*RMEr(x,y)*rand; %alternative perturbation routine, normal 
        %RMtemp(x,y) = RM(x,y) +  RMEr(x,y)*(1 + (-1-1).*rand(1,1)); %alternative perturbation routine, uniform
        y = y +1 ;
         
    end
    
  
%select transport cost or no cost simulations***

FBAfunction5001pwf('Models/EcMREpaper1.mat', 'ATPm',RMtemp(1,1),RMtemp(1,2),RMtemp(1,3), RMtemp(1,4), RMtemp(1,5), RMtemp(1,6), RMtemp(1,7), RMtemp(1,8), RMtemp(1,9),RMtemp(1,10),MREc(16), MREmu(16), satnGlc(20),satnNH3(20), pwf(z,1), pwf(z,2), pwf(z,3));
 
if isempty(ans)
    MREout(1:rxnno,loop) = 0; %fluxes output
    MREout(rxnno+1, loop) = 0; %PO number
    MREout(rxnno+2, loop) = 0; %ATP synthase
    MREout(rxnno+3,loop) = 0 ;% glycolysis split
    MREout(rxnno+4,loop) = 0; %NADPH from PPP
    MREout(rxnno+5,loop) = 0 ; %NADPH from PntAB
    MREout(rxnno+6,loop) = 0; %NADPH from Icd
       
else
    
    MREout(1:rxnno,loop) = ans ; %fluxes output
    MREout(rxnno+1,loop) = ans(45)/(ans(29) + ans(39) + ans(42) + ans(43) + ans(45) + ans(46)) + (0.5*ans(47))/(ans(47) + ans(48) + ans(49)) + ans(49)/(ans(47) + ans(48) +  ans(49)); %PO
    MREout(rxnno+2,loop) = (ans(50)+abs(ans(51)))*118.56/(3.7864*exp(ans(64)*0.7946)); %ATP synthase enzymes per nm^2
    MREout(rxnno+3,loop) = ans(4)/(ans(4) + ans(14)) ;% glycolysis split
    MREout(rxnno+4,loop) = ans(14)/(ans(14)+ans(26)+ans(53)); %NADPH from PPP
    MREout(rxnno+5,loop) = ans(53)/(ans(14)+ans(26)+ans(53)) ; %NADPH from PntAB
    MREout(rxnno+6,loop) = ans(26)/(ans(14)+ans(26)+ans(53)); %NADPH from Icd
      
end

loop = loop + 1 ;

end
 
%Excel output file information

Descr = ["250929Ec5000pwfB_" + z + ".xlsx"];    %***

file = Descr; 
%rang = 'A2:CV93';                        
%coln = 'A1:BF1';                         

if z== 1  
         
        tab = 'PWF1'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA1_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
            
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end
if z== 2  
         
        tab = 'PWF2'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA2_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end

if z== 3  
         
        tab = 'PWF3'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA3_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end

 if z== 4  
         
        tab = 'PWF4'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA4_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
           mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end
if z== 5  
         
        tab = 'PWF5'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA5_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
            
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end
if z== 6  
         
        tab = 'PWF6'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA6_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end

if z== 7  
         
        tab = 'PWF7'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA7_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end

 if z== 8  
         
        tab = 'PWF8'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA8_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
           mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
 end
   
 if z== 9  
         
        tab = 'PWF9'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MSA9_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end   
 end
if z== 10  
         
       tab = 'PWF10'; 
       MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA10_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
end
if z== 11  
         
      tab = 'PWF11'; 
      MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
      if isempty(MREout)
            'MSA11_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
      else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
end
if z== 12  
         
        tab = 'PWF12'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA12_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
end
if z== 13  
         
        tab = 'PWF13'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA13_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
end
if z== 14  
         
        tab = 'PWF14'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA14_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            %xlswrite(file,MREout,tab);
        end 
end
if z== 15  
        
        tab = 'PWF15'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA15_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            %xlswrite(file,MREout,tab);
        end 
end

if z== 16
        pwf(z,:)
        tab = 'PWF16'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA16_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            %xlswrite(file,MREout,tab);
        end 
end     

if z== 17  
         
        tab = 'PWF17'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA17_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            %xlswrite(file,MREout,tab);
       end 
       end      

if z== 18  
         
        tab = 'PWF18'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA18_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            %xlswrite(file,MREout,tab);
       end 
       end      

if z== 19  
         
        tab = 'PWF19'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA19_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            %xlswrite(file,MREout,tab);
       end 
end      

if z== 20  
         
        tab = 'PWF20'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA20_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            %xlswrite(file,MREout,tab);
       end 
end      
     z = z + 1 ;
end   
end
 
