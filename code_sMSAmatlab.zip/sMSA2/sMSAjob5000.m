
%sMSAjob5000, September 2025
%modified from EcMREjobGLA2500, October 2022 - May 2023 
%accounts for PtsG saturation, May 2024; accounts for growth rate dependent protein
%weighting factors, September 2025

% Calculates phenotype constrained by membrane surface area and protein crowding, fixes two
% resource demands mu and qglucose (or qmATP) and maximizes ATP (qmATP) (or minimizes substrate (glucose)) flux to achieve
% optimization
% Ross P. Carlson 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
clear

%initial values

k = 1; % overall counter per z  
y = 1; % counter for mu loop
z = 8; % counter for MRE values
zmax = 13 ; % counter for MRE percentages
MWglc = 0.18; %molecular weight glucose, mmol basis, units g     
MWlac = 0.09; %molecular weight lactate, mmol basis, units g     
MWace = 0.06; %molecular weight acetate, mmol basis, units g      
subglc = 1 ; % reaction glucose 
sublac = 72 ;% reaction lacate in 
subace = 68 ;% reaction acetate in 
biom = 64; % model row for biomass growth

%SA:V Si et al 2017 MG1655 (fMSA 1-20%)
MREc = [1.4089;	2.8179;	4.2268;	5.6358; 7.0447;	8.4537;	9.8627;	11.2716;	12.6806;	14.08953;	15.4985;	16.9075;	18.3164;	19.7254;	21.1343;	22.5433;	23.9522;	25.3612;	26.7702;	28.1791]; %non growth parameters for (1-20%) MRE 
MREmu = [0.2883;	0.5766;	0.865;	1.1533; 1.4416;	1.73;	2.0183;	2.3066;	2.595;	2.8833;	3.1716;	3.46;	3.7483;	4.0366;	4.325;	4.6133;	4.9016;	5.19;	5.4783;	5.7666] ; %growth associated parameters for (1-20%) MRE

%SA:V Si et al 2017 NCM3722 (fMSA 1-20%)
%MREc = [1.9370;	3.8741;	5.8112;	7.7483; 9.6854;	11.6225;	13.5595;	15.4966;	17.4337;	19.3708;	21.3079;	23.245;	25.1820;	27.1191;	29.0562;	30.9933;	32.9304;	34.8675;	36.8045;	38.7416]; %non growth parameters for (1-20%) MRE 
%MREmu = [0.5508;	1.1016;	1.6525;	2.2033; 2.7541;	3.305;	3.8558;	4.4066;	4.9575;	5.5083;	6.0591;	6.61;	7.1608;	7.7116;	8.2625;	8.8133;	9.3641;	9.915;	10.4658;	11.0166] ; %growth associated parameters for (1-20%) MRE

%Model file: EcMREpaper1.mat
ModRxnList = ["Rx1 G1 ";   "Rx2 G2a ";    "Rx3  G2b "; "Rx4  G3r "; "Rx5  G4";   "Rx6  G5";   "Rx7  G6r";  "Rx8  G7r";  "Rx9  G8r";  "Rx10  G9r"; "Rx11  G10r";    "Rx12  G11r";    "Rx13  G12r";    "Rx14  PPP1r";   "Rx15  PPP2r";   "Rx16  PPP3";    "Rx17  PPP4";    "Rx18  PPP5";    "Rx19  PPP6r";   "Rx20  PPP7r";   "Rx21  PPP8r";...
    "Rx22  PPP9r ";  "Rx23  PPP10r "; "Rx24  TCA1";    "Rx25  TCA2r";   "Rx26:  TCA3";   "Rx27  TCA4";    "Rx28  TCA5r ";  "Rx29  TCA6";    "Rx30  TCA7";    "Rx31  TCA8r";   "Rx32  TCA9r";   "Rx33  AP1"; "Rx34  AP2"; "Rx35  AP3"; "Rx36  IM1"; "Rx37  IM2"; "Rx38  IM3"; "Rx39  IM3b";    "Rx40  IM4"; "Rx41  IM5r";    "Rx42  IM6 ";...
    "Rx43  IM7"; "R44  IM8"; "Rx5  R1";  "Rx46  R2";  "Rx47  R3";  "Rx48  R4 "; "Rx49  R5";  "Rx50  R6 (ATPaseF)"; "Rx51  R6r (ATPaseR)";   "Rx52  R7";  "Rx53  R8";  "Rx54  GS1r ";   "Rx55  GS2"; "Rx56  AA1"; "Rx57  AA2"; "Rx58  AA3r ";   "Rx59  ATPm";   "Rx60  ADK ";    "Rx61  PYRO ";   "Rx62  PH";  "Rx63  Phin";    "Rx64  BIOM ";   "Rx65  T1 (Eto)";...
    "Rx66  T2 (Ace)"; "Rx67  T2cost (Ace)";   "Rx68  T2in (Ace)";    "Rx69  T3 (NH3)";    "Rx70 T4 (Lac)"; "Rx71  T4cost (Lac)";  "Rx72  T4in (Lac)";  "Rx73  T5 (For)";  "Rx74  T5cost (For)";  "Rx75  T6 (CO2)";    "Rx76  T6in (CO2) ";   "Rx77  T7 (O2)"; "Rx78  T8";  "Rx79  T9 (H2O)";    "Rx80  T9in (H2O)";    "Rx81  T10 (PO4)"; "Rx82  T11 (Pyr) "; "Rx83  T11cost (Pyr) "; "Rx84  T11in (Pyr) "; "Rx85  T12 (succ)"; "Rx86  T12cost (succ)"; "Rx87  T12in (succ)";  "Rx88  T25 (MRE)";   "Rx89  T26 (Emol)";   "Rx90  T27 (Cmol)";   "Rx91  T28 (mol) "; "Yx/s" ; "P/O" ; "g glc / g biom" ; "MRE/ATP"];   

s = 91; %number of reactions in EcMREModel    

%specific rates for constraints

%vATPm = [0 1 3 5 7 9	11	13	15 17 19 21	23 25 27	29 31 33	35 37 39	41	43 45 47	49 51 53 55	57 59 61 63	65	67 69	71 73	75	77	79	81 83 85	87 89 91 93 95 97 99 101 103 105 107 109 111 113 115 117 119 121];
%qglucose units of mmol/ (g cdw h)
qglc = [0.01 0.05 0.1 0.125 0.15 0.175	0.2 0.225 0.25 0.275 0.3 0.325 0.35 0.375 0.4 0.425	0.45 0.475 0.5 0.525 0.55 0.575	0.6 0.65 0.7	0.75 0.8 0.85 0.9	0.95 1 1.1 1.2 1.3 1.4	1.5 1.6 1.7 1.8 1.9	2 2.2 2.4	2.6 2.8	3 3.2 3.4 3.6 3.8	4 4.2 4.4 4.6 4.8 5	5.2 5.4 5.6 5.8	6 6.2 6.4 6.6 6.8	7 7.25	7.5	7.75 8 8.25	8.5 8.75	9	9.5	10	10.5	11	11.5	12	12.5	13	13.5	14	14.5	15 15.5	16 16.5	17 17.5	18 18.5	19 19.5	20 20.5	21 21.5	22 22.5	23	24	];

n = size(qglc, 2) ;% counter for number of increases in qglc

Output = zeros(s+2,(n)*(n+35)); %preallocate output matrix

while z < zmax +1 %cycles through MRE percentages 

  Output = zeros(s+2,(n)*(n+35)); %preallocate output matrix  
  mu = 0.01 ;%  initial mu
  k = 1 ;
  y = 1 ;
  
while y < n + 73 %cycles through mu 

i = 1;

while i < n %cycles through qglc

    %qatp = vATPm(i) ;
    G1 = qglc(i) ;

sMSAFBAfunction5000('Models/EcMREpaper2.mat','ATPm',G1, mu, MREc(z), MREmu(z));  %   ***

if isempty(ans)
    Output(1:s,k) = 0;
    Output(s+1,k) = 0 ;
    Output(s+2,k) = 0 ;
else
    Output(1:s,k) = ans ;
    %biomass yield on substrate, can use glucose, acetate, or lactate
    Output(s+1, k) = Output(biom,k)/((Output(subglc,k))*MWglc + (Output(sublac,k))*MWlac + (Output(subace,k))*MWace); %biomass yield on substrate
    %P/O number
    Output(s+2, k) = Output(45,k)/(Output(29,k) + Output(39,k) + Output(42,k) + Output(43,k) + Output(45,k) + Output(46,k) + Output(81,k)) + (0.5*Output(47,k))/(Output(47,k) + Output(48,k) + Output(49,k)) + Output(49,k)/(Output(47,k) + Output(48,k) +  Output(49,k)); %PO
    %gram substrate per gram biomass
    Output(s+3, k) = 1/(Output(s+1,k));
    %MRE per qATP
    Output(s+4, k) = (Output(92,k)-Output(63,k)*MREmu(z))/(Output(58,k));

end

k = k + 1;
i = i+1 ;

end

mu = mu + 0.01 ;

y = y + 1 ;
end

Descr = ['251019sMSA_5003Anaero', '.xlsx'];    %***
file = Descr; 
rang = 'B1:JIF99';                        
coln = 'A1:A99';                         

if z== 5  
         
        tab = 'MSA5%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file,ModRxnList(:),tab,coln) ;   
        EucD5 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
   
 if z== 6  
         
        tab = 'MSA6%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file,ModRxnList(:),tab,coln) ; 
        EucD6 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
 end
if z== 7  
        
        tab = 'MSA7%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD7 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 8  
         
        tab = 'MSA8%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD8 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 9  
         
        tab = 'MSA9%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD9 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 10  
         
        tab = 'MSA10%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ;
        EucD10 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 11  
         
        tab = 'MSA11%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD11 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 12  
         
        tab = 'MSA12%';
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD12 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 13  
         
        tab = 'MSA13%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD13 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 14  
        
        tab = 'MSA14%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD14 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end

if z== 15  
         
        tab = 'MSA15%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD15 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 16  
         
        tab = 'MSA16%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD16 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 17  
         
        tab = 'MSA17%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD17 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 18  
         
        tab = 'MSA18%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD18 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 19  
         
        tab = 'MSA19%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD19 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
if z== 20  
         
        tab = 'MSA20%'; 
        Output(:,all(Output ==0)) = [];
        xlswrite(file,Output,tab,rang);
        xlswrite(file, ModRxnList(:),tab,coln) ; 
        EucD20 = [Output(1,:);Output(58,:); Output(63,:);Output(65,:);Output(92,:);Output(93,:)];
end
z = z + 1 ;
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%