function[mF, sF] = functionEc5000(i, zmax, rowtrack) 

%Ec5000AeroCost/NoCost
%December 2022-December 2023, March 2024, June/July 2024, August 2025  
%Ross P. Carlson
%cost analysis for aerobic cultures, glucose and iron limited (nitrogen
%separate due to saturation of transporter)
%analyzes median experimental chemostat data using surface area constraints
%using temperature corrected TO numbers
%corrects the transporter saturation term for the chemostat conditions

%SA:V Si et al 2017 MG1655 (fMSA 1-20%)
MREc = [1.4089;	2.8179;	4.2268;	5.6358; 7.0447;	8.4537;	9.8627;	11.2716;	12.6806;	14.08953;	15.4985;	16.9075;	18.3164;	19.7254;	21.1343;	22.5433;	23.9522;	25.3612;	26.7702;	28.1791]; %non growth parameters for (1-20%) MRE 
MREmu = [0.2883;	0.5766;	0.865;	1.1533; 1.4416;	1.73;	2.0183;	2.3066;	2.595;	2.8833;	3.1716;	3.46;	3.7483;	4.0366;	4.325;	4.6133;	4.9016;	5.19;	5.4783;	5.7666] ; %growth associated parameters for (1-20%) MRE

%SA:V Si et al 2017 NCM3722 (fMSA 1-20%)
%MREc = [1.9370;	3.8741;	5.8112;	7.7483; 9.6854;	11.6225;	13.5595;	15.4966;	17.4337;	19.3708;	21.3079;	23.245;	25.1820;	27.1191;	29.0562;	30.9933;	32.9304;	34.8675;	36.8045;	38.7416]; %non growth parameters for (1-20%) MRE 
%MREmu = [0.5508;	1.1016;	1.6525;	2.2033; 2.7541;	3.305;	3.8558;	4.4066;	4.9575;	5.5083;	6.0591;	6.61;	7.1608;	7.7116;	8.2625;	8.8133;	9.3641;	9.915;	10.4658;	11.0166] ; %growth associated parameters for (1-20%) MRE

% limiting substrate transporter saturation for growth rates in data set,
% PtsG glucose transporter saturation, Amt NH4+ transporter saturation
satnGlc = [0.15	0.22	0.30	0.37	0.45	0.50	0.55	0.60	0.65	0.70	0.75	0.80	0.84	0.90	0.94	0.99	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	0.10	0.20	0.30	0.40	0.50	0.60	0.70	0.80	0.90	1.00	1.00	1.00	1.00	1.00	1.00	1.00];
satnNH3 = [1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	0.15	0.15	0.30	0.30	0.45	0.60	0.82	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00	1.00]; 

%experimental data (order of columns: growth
%rate, glucose, pyruvate, succinate, lactate out, lactate in, formate,
%acetate out, acetate in, ethanol out)

%rows: 1-23, aerobic cstr/batch, glucose limited, consensus data MG1655
%rows: 24-46, aerobic cstr/batch, glucose limited, consensus data NCM3722
%rows: 47-67, aerobic batch G, GA, L, A  MG1655
%rows: 68-74, aerobic cstr nitrogen limited MG1655
%rows: 75-78, aerobic cstr iron limited MG1655
%rows: 79-94, anaerobic, glucose limited consensus data MG1655


RM = [0.10	1.57	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.15	2.22	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.20	2.88	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.25	3.54	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.30	4.19	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.33	4.63	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.37	5.06	0.00	0.00	0.00	0.00	0.00	0.20	0.00	0.00
0.40	5.51	0.00	0.00	0.00	0.00	0.00	0.53	0.00	0.00
0.43	5.94	0.00	0.00	0.00	0.00	0.00	0.84	0.00	0.00
0.47	6.38	0.00	0.00	0.00	0.00	0.00	1.16	0.00	0.00
0.50	6.82	0.00	0.00	0.00	0.00	0.00	1.48	0.00	0.00
0.53	7.26	0.00	0.00	0.00	0.00	0.00	1.80	0.00	0.00
0.57	7.69	0.00	0.00	0.00	0.00	0.00	2.12	0.00	0.00
0.60	8.14	0.00	0.00	0.00	0.00	0.00	2.44	0.00	0.00
0.63	8.57	0.00	0.00	0.00	0.00	0.00	2.76	0.00	0.00
0.67	9.00	0.00	0.00	0.00	0.00	0.00	3.07	0.00	0.00
0.70	9.45	0.00	0.00	0.00	0.00	0.00	3.40	0.00	0.00
0.73	9.88	0.00	0.00	0.00	0.00	0.00	3.71	0.00	0.00
0.77	10.32	0.00	0.00	0.00	0.00	0.00	4.03	0.00	0.00
0.80	10.76	0.00	0.00	0.00	0.00	0.00	4.35	0.00	0.00
0.83	11.20	0.00	0.00	0.00	0.00	0.00	4.67	0.00	0.00
0.87	11.63	0.00	0.00	0.00	0.00	0.00	4.99	0.00	0.00
0.90	12.08	0.00	0.00	0.00	0.00	0.00	5.31	0.00	0.00
0.10	1.50	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.15	2.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.20	2.50	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.25	3.02	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.30	3.55	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.35	4.09	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.40	4.63	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.45	5.18	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.50	5.73	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.55	6.26	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.60	6.80	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.65	7.40	0.00	0.00	0.00	0.00	0.00	0.13	0.00	0.00
0.70	8.00	0.00	0.00	0.00	0.00	0.00	0.25	0.00	0.00
0.75	8.77	0.00	0.00	0.00	0.00	0.00	0.80	0.00	0.00
0.80	9.35	0.00	0.00	0.00	0.00	0.00	1.40	0.00	0.00
0.85	10.40	0.00	0.00	0.00	0.00	0.00	3.00	0.00	0.00
0.90	11.40	0.00	0.00	0.00	0.00	0.00	5.00	0.00	0.00
0.95	12.70	0.00	0.00	0.00	0.00	0.00	7.30	0.00	0.00
1.00	14.00	0.00	0.00	0.00	0.00	0.00	9.30	0.00	0.00
1.05	15.43	0.00	0.00	0.00	0.00	0.00	11.78	0.00	0.00
1.10	17.06	0.00	0.00	0.00	0.00	0.00	14.34	0.00	0.00
1.15	18.87	0.00	0.00	0.00	0.00	0.00	17.06	0.00	0.00
1.20	20.86	0.00	0.00	0.00	0.00	0.00	19.94	0.00	0.00
0.67	8.66	0.00	0.00	0.00	0.00	0.00	2.58	0.00	0.00
0.65	9.10	0.00	0.00	0.00	0.00	0.00	2.83	0.00	0.00
0.67	9.46	0.00	0.00	0.00	0.00	0.00	2.37	0.00	0.00
0.70	6.75	0.00	0.00	0.00	4.25	0.00	3.66	0.00	0.00
0.71	7.55	0.00	0.00	0.00	4.83	0.00	4.34	0.00	0.00
0.71	7.31	0.00	0.00	0.00	4.98	0.00	4.02	0.00	0.00
0.65	9.16	0.00	0.00	0.00	0.00	0.00	3.05	0.00	0.00
0.67	9.68	0.00	0.00	0.00	0.00	0.00	3.18	0.00	0.00
0.68	9.29	0.00	0.00	0.00	0.00	0.00	2.72	0.00	0.00
0.66	7.84	0.00	0.00	0.00	3.76	0.00	4.38	0.00	0.00
0.62	8.19	0.00	0.00	0.00	3.45	0.00	5.34	0.00	0.00
0.64	8.01	0.00	0.00	0.00	3.61	0.00	4.86	0.00	0.00
0.38	0.00	0.00	0.00	0.00	18.14	0.00	6.33	0.00	0.00
0.36	0.00	0.00	0.00	0.00	16.59	0.00	9.27	0.00	0.00
0.38	0.00	0.00	0.00	0.00	17.69	0.00	7.76	0.00	0.00
0.36	0.00	0.00	0.00	0.00	17.12	0.00	7.13	0.00	0.00
0.37	0.00	0.00	0.00	0.00	17.46	0.00	7.10	0.00	0.00
0.38	0.00	0.00	0.00	0.00	17.14	0.00	7.23	0.00	0.00
0.21	0.00	0.00	0.00	0.00	0.00	0.00	0.00	9.76	0.00
0.22	0.00	0.00	0.00	0.00	0.00	0.00	0.00	9.92	0.00
0.22	0.00	0.00	0.00	0.00	0.00	0.00	0.00	10.18	0.00
0.10	2.90	0.00	0.00	0.00	0.00	0.00	1.60	0.00	0.00
0.10	3.51	0.04	0.00	0.86	0.00	0.00	5.26	0.00	0.00
0.20	6.40	0.80	0.00	0.00	0.00	0.00	4.40	0.00	0.00
0.20	6.57	0.00	0.00	0.64	0.00	0.00	5.16	0.00	0.00
0.30	8.36	0.00	0.00	0.60	0.00	0.00	6.19	0.00	0.00
0.40	9.27	0.00	0.00	0.53	0.00	0.00	6.40	0.00	0.00
0.55	8.60	0.00	0.00	0.00	0.00	0.00	2.55	0.00	0.00
0.10	13.70	0.00	0.10	16.19	0.00	2.87	2.79	0.00	0.00
0.20	9.61	1.99	0.12	7.20	0.00	1.32	2.43	0.00	0.00
0.30	9.71	1.11	0.09	5.47	0.00	1.72	4.79	0.00	0.00
0.40	6.82	0.18	0.04	1.08	0.00	1.7 	7.08	0.00	0.00
0.05	6.954	0	0.705	0	0	8.23	4.4215	0	4.4045
0.1	8.328	0	0.84	0	0	10.18	5.453	0	5.299
0.15	9.702	0	0.975	0	0	12.13	6.4845	0	6.1935
0.2	11.076	0	1.11	0	0	14.08	7.516	0	7.088
0.25	12.45	0	1.245	0	0	16.03	8.5475	0	7.9825
0.3	13.824	0	1.38	0	0	17.98	9.579	0	8.877
0.35	15.198	0	1.515	0	0	19.93	10.6105	0	9.7715
0.4	16.572	0	1.65	0	0	21.88	11.642	0	10.666
0.45	17.946	0	1.785	0	0	23.83	12.6735	0	11.5605
0.5	19.32	0	1.92	0	0	25.78	13.705	0	12.455
0.55	20.694	0	2.055	0	0	27.73	14.7365	0	13.3495
0.6	22.068	0	2.19	0	0	29.68	15.768	0	14.244
0.65	23.442	0	2.325	0	0	31.63	16.7995	0	15.1385
0.7	24.816	0	2.46	0	0	33.58	17.831	0	16.033
0.75	26.19	0	2.595	0	0	35.53	18.8625	0	16.9275
0.8	27.564	0	2.73	0	0	37.48	19.894	0	17.822];

%error in experimental data, same order as original rates  
RMEr = [0.01	0.11	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.16	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.20	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.25	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.29	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.32	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.35	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.39	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.42	0.00	0.00	0.00	0.00	0.00	0.06	0.00	0.00
0.02	0.45	0.00	0.00	0.00	0.00	0.00	0.08	0.00	0.00
0.02	0.48	0.00	0.00	0.00	0.00	0.00	0.10	0.00	0.00
0.02	0.51	0.00	0.00	0.00	0.00	0.00	0.13	0.00	0.00
0.02	0.54	0.00	0.00	0.00	0.00	0.00	0.15	0.00	0.00
0.02	0.57	0.00	0.00	0.00	0.00	0.00	0.17	0.00	0.00
0.02	0.60	0.00	0.00	0.00	0.00	0.00	0.19	0.00	0.00
0.02	0.63	0.00	0.00	0.00	0.00	0.00	0.22	0.00	0.00
0.02	0.66	0.00	0.00	0.00	0.00	0.00	0.24	0.00	0.00
0.02	0.69	0.00	0.00	0.00	0.00	0.00	0.26	0.00	0.00
0.02	0.72	0.00	0.00	0.00	0.00	0.00	0.28	0.00	0.00
0.02	0.75	0.00	0.00	0.00	0.00	0.00	0.30	0.00	0.00
0.02	0.78	0.00	0.00	0.00	0.00	0.00	0.33	0.00	0.00
0.02	0.81	0.00	0.00	0.00	0.00	0.00	0.35	0.00	0.00
0.02	0.85	0.00	0.00	0.00	0.00	0.00	0.37	0.00	0.00
0.01	0.11	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.14	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.18	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.21	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.25	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.29	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.32	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.36	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.40	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.44	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.48	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.52	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.01	0.56	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.61	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.00
0.02	0.65	0.00	0.00	0.00	0.00	0.00	0.10	0.00	0.00
0.02	0.73	0.00	0.00	0.00	0.00	0.00	0.21	0.00	0.00
0.02	0.80	0.00	0.00	0.00	0.00	0.00	0.35	0.00	0.00
0.02	0.89	0.00	0.00	0.00	0.00	0.00	0.51	0.00	0.00
0.02	0.98	0.00	0.00	0.00	0.00	0.00	0.65	0.00	0.00
0.02	1.08	0.00	0.00	0.00	0.00	0.00	0.82	0.00	0.00
0.02	1.19	0.00	0.00	0.00	0.00	0.00	1.00	0.00	0.00
0.02	1.32	0.00	0.00	0.00	0.00	0.00	1.19	0.00	0.00
0.02	1.46	0.00	0.00	0.00	0.00	0.00	1.40	0.00	0.00
0.01	0.40	0.00	0.00	0.00	0.00	0.00	0.23	0.00	0.00
0.01	0.40	0.00	0.00	0.00	0.00	0.00	0.23	0.00	0.00
0.01	0.40	0.00	0.00	0.00	0.00	0.00	0.23	0.00	0.00
0.01	0.41	0.00	0.00	0.00	0.39	0.00	0.34	0.00	0.00
0.01	0.41	0.00	0.00	0.00	0.39	0.00	0.34	0.00	0.00
0.01	0.41	0.00	0.00	0.00	0.39	0.00	0.34	0.00	0.00
0.01	0.27	0.00	0.00	0.00	0.00	0.00	0.24	0.00	0.00
0.01	0.27	0.00	0.00	0.00	0.00	0.00	0.24	0.00	0.00
0.01	0.27	0.00	0.00	0.00	0.00	0.00	0.24	0.00	0.00
0.02	0.18	0.00	0.00	0.00	0.16	0.00	0.48	0.00	0.00
0.02	0.18	0.00	0.00	0.00	0.16	0.00	0.48	0.00	0.00
0.02	0.18	0.00	0.00	0.00	0.16	0.00	0.48	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.80	0.00	0.48	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.80	0.00	0.48	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.80	0.00	0.48	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.20	0.00	0.07	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.20	0.00	0.07	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.20	0.00	0.07	0.00	0.00
0.01	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.21	0.00
0.01	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.21	0.00
0.01	0.00	0.00	0.00	0.00	0.00	0.00	0.00	0.21	0.00
0.01	0.29	0.00	0.00	0.00	0.00	0.00	0.16	0.00	0.00
0.01	0.32	0.00	0.00	0.07	0.00	0.00	0.43	0.00	0.00
0.01	0.64	0.08	0.00	0.00	0.00	0.00	0.44	0.00	0.00
0.01	0.66	0.00	0.00	0.06	0.00	0.00	0.52	0.00	0.00
0.01	0.84	0.00	0.00	0.06	0.00	0.00	0.62	0.00	0.00
0.01	0.93	0.00	0.00	0.05	0.00	0.00	0.64	0.00	0.00
0.01	0.86	0.00	0.00	0.00	0.00	0.00	0.26	0.00	0.00
0.01	2.76	0.00	0.02	2.53	0.00	0.37	0.40	0.00	0.00
0.01	1.90	0.49	0.05	0.85	0.00	0.23	0.27	0.00	0.00
0.02	1.17	0.42	0.03	0.58	0.00	0.15	0.28	0.00	0.00
0.02	3.62	0.20	0.02	0.76	0.00	0.81	1.98	0.00	0.00
0.01	0.72	0.00	0.07	0.00	0.00	0.83	0.46	0.00	0.43
0.01	0.84	0.00	0.08	0.00	0.00	1.02	0.55	0.00	0.52
0.02	0.96	0.00	0.10	0.00	0.00	1.21	0.65	0.00	0.62
0.02	1.09	0.00	0.11	0.00	0.00	1.39	0.75	0.00	0.71
0.03	1.21	0.00	0.13	0.00	0.00	1.58	0.84	0.00	0.80
0.03	1.34	0.00	0.14	0.00	0.00	1.77	0.94	0.00	0.89
0.03	1.46	0.00	0.16	0.00	0.00	1.96	1.03	0.00	0.98
0.03	1.58	0.00	0.17	0.00	0.00	2.14	1.13	0.00	1.08
0.03	1.71	0.00	0.18	0.00	0.00	2.33	1.23	0.00	1.17
0.03	1.83	0.00	0.20	0.00	0.00	2.52	1.32	0.00	1.26
0.03	1.96	0.00	0.21	0.00	0.00	2.71	1.42	0.00	1.35
0.03	2.08	0.00	0.23	0.00	0.00	2.89	1.52	0.00	1.44
0.03	2.20	0.00	0.24	0.00	0.00	3.08	1.61	0.00	1.54
0.03	2.33	0.00	0.26	0.00	0.00	3.27	1.71	0.00	1.63
0.03	2.45	0.00	0.27	0.00	0.00	3.46	1.81	0.00	1.72
0.03	2.58	0.00	0.28	0.00	0.00	3.64	1.90	0.00	1.81];

totno = 100 ; %100 perturbations
rxnno = 91; %reactions in model (EcMREpaper1)

%vector to be pulled from function

mF = zeros(rowtrack, zmax); %median flux for each reaction or function
sF = zeros(rowtrack, zmax); %standard deviation for each reaction or function

%number of experimental conditions
LR = size(RM,1);
%number of experimental rates considered
LC = size(RM,2);

z = 1 ; %starting MSA % 

while z < zmax +1  %cycles through MSA %, set with z and zmax

%output
MREout = zeros(rxnno + 6,totno);
 
loop = 1; 

%temporary RM with perturbations
RMtemp = zeros(LR, LC);

%one hundred perturbations loop
while loop <totno + 1  

%module for perturbing the experimental values within their limits

x = 1; % row counter
y = 1;  % column counter

while x < LR+1   
    
    y = 1 ;
    while y < LC+1 
        
        RMtemp(x,y) = RM(x,y) + (randi([-1,1],1,1))*RMEr(x,y)*rand; %alternative perturbation routine, normal 
        %RMtemp(x,y) = RM(x,y) +  RMEr(x,y)*(1 + (-1-1).*rand(1,1)); %alternative perturbation routine, uniform
        y = y +1 ;
         
    end
    
    x = x + 1 ;
    
end

%select transport cost or no cost simulations***
%aerobic code
%FBAfunction5001('Models/EcMREpaper1.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,4), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),RMtemp(i,10),MREc(z), MREmu(z), satnGlc(i),satnNH3(i));
%FBAfunction5001FeN('Models/EcMREpaper2.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,4), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),RMtemp(i,10),MREc(z), MREmu(z), satnGlc(i),satnNH3(i));
FBAfunction5002('Models/EcMREpaper1.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,4), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),RMtemp(i,10),MREc(z), MREmu(z), satnGlc(i),satnNH3(i));

%anaerobic code
%FBAfunction5003('Models/EcMREpaper2.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,4), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),RMtemp(i,10),MREc(z), MREmu(z), satnGlc(i),satnNH3(i));
%FBAfunction5004('Models/EcMREpaper2.mat', 'ATPm',RMtemp(i,1),RMtemp(i,2),RMtemp(i,3), RMtemp(i,4), RMtemp(i,5), RMtemp(i,6), RMtemp(i,7), RMtemp(i,8), RMtemp(i,9),RMtemp(i,10),MREc(z), MREmu(z), satnGlc(i),satnNH3(i));

if isempty(ans)
    MREout(1:rxnno,loop) = 0; %fluxes output
    MREout(rxnno+1, loop) = 0; %PO number
    MREout(rxnno+2, loop) = 0; %ATP synthase
    MREout(rxnno+3,loop) = 0 ;% glycolysis split
    MREout(rxnno+4,loop) = 0; %NADPH from PPP
    MREout(rxnno+5,loop) = 0 ; %NADPH from PntAB
    MREout(rxnno+6,loop) = 0; %NADPH from Icd
       
else
    
    MREout(1:rxnno,loop) = ans ; %fluxes output
    MREout(rxnno+1,loop) = ans(45)/(ans(29) + ans(39) + ans(42) + ans(43) + ans(45) + ans(46)) + (0.5*ans(47))/(ans(47) + ans(48) + ans(49)) + ans(49)/(ans(47) + ans(48) +  ans(49)); %PO
    MREout(rxnno+2,loop) = (ans(50)+abs(ans(51)))*118.56/(3.7864*exp(ans(64)*0.7946)); %ATP synthase enzymes per nm^2
    MREout(rxnno+3,loop) = ans(4)/(ans(4) + ans(14)) ;% glycolysis split
    MREout(rxnno+4,loop) = ans(14)/(ans(14)+ans(26)+ans(53)); %NADPH from PPP
    MREout(rxnno+5,loop) = ans(53)/(ans(14)+ans(26)+ans(53)) ; %NADPH from PntAB
    MREout(rxnno+6,loop) = ans(26)/(ans(14)+ans(26)+ans(53)); %NADPH from Icd
      
end

loop = loop + 1 ;

end
 
%Excel output file information

Descr = ["260322c5002MG_" + i + ".xlsx"];    %***
 

file = Descr; 
%rang = 'A2:CV93';                        
%coln = 'A1:BF1';                         

if z== 1  
         
        tab = 'MSA1'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA1_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
            
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end
if z== 2  
         
        tab = 'MSA 2'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA2_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end

if z== 3  
         
        tab = 'MSA 3'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA3_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end

 if z== 4  
         
        tab = 'MSA 4'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA4_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
           mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end
if z== 5  
         
        tab = 'MSA 5'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA5_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
            
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end
if z== 6  
         
        tab = 'MSA 6'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA6_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end

if z== 7  
         
        tab = 'MSA 7'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA7_empty ', 
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end

 if z== 8  
         
        tab = 'MSA 8'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA8_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
           mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
 end
   
 if z== 9  
         
        tab = 'MSA 9'; 
        MREout(:,all(MREout ==0)) = [];
        if isempty(MREout)
            'MSA9_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end   
 end
if z== 10  
         
       tab = 'MSA 10'; 
       MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA10_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
end
if z== 11  
         
      tab = 'MSA 11'; 
      MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
      if isempty(MREout)
            'MSA11_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
      else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
end
if z== 12  
         
        tab = 'MSA 12'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA12_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
end
if z== 13  
         
        tab = 'MSA 13'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA13_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
end
if z== 14  
         
        tab = 'MSA 14'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA14_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            xlswrite(file,MREout,tab);
        end 
end
if z== 15  
        
        tab = 'MSA 15'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA15_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            xlswrite(file,MREout,tab);
        end 
end

if z== 16
        
        tab = 'MSA 16'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
        if isempty(MREout)
            'MSA16_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
        else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            xlswrite(file,MREout,tab);
        end 
end     

if z== 17  
         
        tab = 'MSA 17'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA17_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            xlswrite(file,MREout,tab);
       end 
       end      

if z== 18  
         
        tab = 'MSA 18'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA18_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            xlswrite(file,MREout,tab);
       end 
       end      

if z== 19  
         
        tab = 'MSA 19'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA19_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            xlswrite(file,MREout,tab);
       end 
end      

if z== 20  
         
        tab = 'MSA 20'; 
        MREout(:,all(MREout ==0)) = [];  %sorts empty data sets
       if isempty(MREout)
            'MSA20_empty ',
            mF(:,z) = zeros(rowtrack, 1);
            sF(:,z) = zeros(rowtrack, 1);
       else
            MREout = [MREout (mean(MREout, 2))  (std(MREout,0, 2))]; %adds columns with reaction flux mean and standard deviation
            mF(:,z) = (mean(MREout, 2));
            sF(:,z) = (std(MREout,0, 2));
            xlswrite(file,MREout,tab);
       end 
end      
     z = z + 1 ;
end   
end
 
