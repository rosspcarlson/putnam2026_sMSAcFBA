sMSAc-FBA files for cobratoolbox run with matlab


Files:
OLMRE5000			3/22/2026		overlord code for calling sMSAc-FBA functions
functionEc5000		3/22/2026		sMSAc-FBA function assignment, experimental flux data, perturbation routines, calls specific models for analysis
FBAfunction5001		10/16/2025		aerobic E. coli metabolism, organic acids have NO transport sMSA cost
FBAfunction5002		10/16/2025		aerobic E. coli metabolism, organic acids HAVE transport sMSA cost
FBAfunction5003		10/17/2025		anaerobic E. coli metabolism, organic acids have NO transport sMSA cost
FBAfunction5004		3/22/2026		anaerobic E. coli metabolism, organic acids HAVE transport sMSA cost
				
sMSAFBAfunction5000	10/19/2025		code for generating 3D rate/yield/maintenance energy plots
sMSAjob5000			10/19/2025		code for generating 3D rate/yield/maintenance energy plots
				
OLMRE5000pwf		9/29/2025		code for testing protein weighting factors on correlation of predicted protein abundance and experimental abundance
functionEc5000pwf	9/29/2025		code for testing protein weighting factors on correlation of predicted protein abundance and experimental abundance
				
sMSAplotGYA			6/30/2026		data and script for plotting rate/yield/maintenance energy plots (Figure 8)
				
EcMREpaper1			3/18/2024		aerobic E. coli metabolic model
EcMREpaper2			10/16/2025		anaerobic E. coli metabolic model
